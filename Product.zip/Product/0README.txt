
––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––	
								HELLO! HERE ARE THE INSTRUCTIONS TO RUN THIS APPLICATION

––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––


There are two main ways to run this program:

1) You can access the .jar file that is within the Product directory/folder and double-click it to start the application.

2) You can run the 